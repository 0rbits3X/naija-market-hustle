// Put your Supabase keys here. The zip updater never overwrites this file.
window.CFG={url:"PASTE_YOUR_SUPABASE_URL",key:"PASTE_YOUR_ANON_KEY"};
